package de.janroslan.versefx.draw;

/**
 * Mögliche Status einer Frame-Animation
 * @author jackjan
 */
public enum AnimationState {
    RUNNING, PAUSED, STOPPED
}
